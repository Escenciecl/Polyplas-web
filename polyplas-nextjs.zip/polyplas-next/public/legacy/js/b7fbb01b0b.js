document.addEventListener('DOMContentLoaded', function () {

  if (localStorage.getItem('cookieConsentimiento')) return;

  var estilos = `
    #cookie-banner {
      position: fixed; bottom: 90px; left: 0; right: 0;
      background: #fff;
      box-shadow: 0 4px 20px rgba(0,0,0,0.15);
      border-radius: 12px;
      margin: 0 16px;
      z-index: 2147483647;
      padding: 20px 28px;
      display: flex;
      align-items: center;
      gap: 24px;
      font-family: 'Archivo Narrow', Arial, sans-serif;
    }
    #cookie-banner .cb-icon { flex-shrink: 0; }
    #cookie-banner .cb-text {
      flex: 1; font-size: 15px; color: #333; line-height: 1.5;
    }
    #cookie-banner .cb-actions {
      display: flex; align-items: center; gap: 12px; flex-shrink: 0;
    }
    #cookie-banner .cb-btn {
      border-radius: 10px; padding: 12px 22px; font-size: 15px;
      font-weight: 700; cursor: pointer; white-space: nowrap;
      font-family: 'Archivo Narrow', Arial, sans-serif;
      border: 2px solid #004a99; transition: opacity .15s;
    }
    #cookie-banner .cb-btn:hover { opacity: .85; }
    #cookie-banner .cb-btn-outline { background: #fff; color: #004a99; }
    #cookie-banner .cb-btn-solid   { background: #004a99; color: #fff; }

    @media (max-width: 600px) {
      #cookie-banner {
        flex-direction: column;
        align-items: flex-start;
        padding: 16px 20px;
        gap: 14px;
      }
      #cookie-banner .cb-icon { display: none; }
      #cookie-banner .cb-text { font-size: 14px; }
      #cookie-banner .cb-actions {
        width: 100%; justify-content: stretch; gap: 10px;
      }
      #cookie-banner .cb-btn {
        flex: 1; text-align: center; padding: 11px 10px; font-size: 14px;
      }
    }
  `;

  var style = document.createElement('style');
  style.textContent = estilos;
  document.head.appendChild(style);

  var banner = document.createElement('div');
  banner.id = 'cookie-banner';
  banner.innerHTML = `
    <div class="cb-icon">
      <svg width="44" height="44" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="32" cy="32" r="28" stroke="#004a99" stroke-width="3" fill="none"/>
        <circle cx="22" cy="24" r="3" fill="#004a99"/>
        <circle cx="38" cy="20" r="2" fill="#004a99"/>
        <circle cx="44" cy="34" r="3" fill="#004a99"/>
        <circle cx="28" cy="40" r="2.5" fill="#004a99"/>
        <circle cx="20" cy="38" r="2" fill="#004a99"/>
        <circle cx="36" cy="46" r="2" fill="#004a99"/>
        <path d="M30 26 Q34 22 38 28" stroke="#004a99" stroke-width="2" stroke-linecap="round" fill="none"/>
      </svg>
    </div>
    <div class="cb-text">
      Este sitio web utiliza cookies para mejorar la experiencia de navegación. Al presionar <strong>Aceptar todo</strong> nos otorga autorización para utilizar nuestra
      <a href="https://polyplas.cl/politica-de-privacidad-de-datos/" style="color:#004a99; font-weight:700; text-decoration:underline;">Política de protección de datos</a>.
    </div>
    <div class="cb-actions">
      <button class="cb-btn cb-btn-outline" id="cb-rechazar">Rechazar todo</button>
      <button class="cb-btn cb-btn-solid"   id="cb-aceptar">Aceptar todo</button>
    </div>
  `;
  document.body.appendChild(banner);

  document.getElementById('cb-aceptar').addEventListener('click', function () {
    localStorage.setItem('cookieConsentimiento', 'aceptado');
    gtag('consent', 'update', {
      analytics_storage: 'granted', ad_storage: 'granted',
      ad_user_data: 'granted', ad_personalization: 'granted'
    });
    banner.remove();
  });

  document.getElementById('cb-rechazar').addEventListener('click', function () {
    localStorage.setItem('cookieConsentimiento', 'rechazado');
    gtag('consent', 'update', {
      analytics_storage: 'denied', ad_storage: 'denied',
      ad_user_data: 'denied', ad_personalization: 'denied'
    });
    banner.remove();
  });

});
