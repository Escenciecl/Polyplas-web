# Módulos del sitio Polyplas

Cada carpeta es **una página** y cada archivo `.html` es **un módulo** de esa página
(lo mismo que pegabas en un widget HTML de Elementor: HTML + `<style>` + `<script>`).
Los módulos se muestran en orden según el número del nombre (01, 02, 03…).

| Carpeta | Página |
|---|---|
| `00-flotantes` | Chat de Maca, "Cómo comprar online", cookies y carrito (todas las páginas) |
| `01-inicio` | polyplas.cl |
| `02-nosotros` | /nosotros/ |
| `03-contacto` | /contacto/ |
| `04-planchas-acrilico` … `10-tinas` | Categorías de productos |
| `10b-cascos-de-tinas` | Categoría Cascos de tinas (/categoria-producto/cascos-de-tinas/) |
| `11-guia-acrilicos`, `12-guia-tinas` | Guías |
| `13-blog` | /blog/ (el listado de artículos se arma solo) |
| `20-articulo-…` | Cada artículo del blog |
| `30-gracias` | Página después de pagar |
| `31-…`, `32-…` | Políticas |
| `99-pagina-404` | Página "no encontrada" |

## Menú, cabecera y pie de página

Ya no son módulos: están hechos en React y sus textos se cambian en
`content/sitio/navegacion.json` (barra superior, menú, teléfono, WhatsApp, botón "Cotizar")
y `content/sitio/pie.json` (columnas, contacto, horarios, redes). Cambia solo el texto entre comillas.

## Cambiar un módulo

1. En GitHub entra a la carpeta de la página.
2. **Add file → Upload files** y arrastra tu archivo **con el mismo nombre** del que quieres reemplazar.
3. **Commit changes**. En ~2 minutos está publicado en el sitio.

También puedes abrir el archivo, presionar el lápiz ✏️ y editar el texto directamente.

## Agregar un módulo nuevo

Sube un archivo nuevo con un número, por ejemplo `09-promocion-verano.html`. Aparece al final de la página.

## Quitar un módulo

Abre el archivo y usa el menú **⋯ → Delete file**.

## Título y descripción para Google

Están en `_pagina.json` de cada carpeta: `"titulo"` y `"descripcion"`.
Cambia solo el texto entre comillas.

## No tocar

- `_estructura.html`: es el armazón de Elementor que ordena los módulos.
- No cambies `"url"` en `_pagina.json`: cambiaría la dirección de la página y se perdería posicionamiento en Google.

## Precios y stock: manda el CRM

El precio, el precio anterior y la cantidad de **todos** los productos se cambian en el CRM
(pestaña *Gestión de Stock*), que los guarda en la tabla `pp_stock` de Supabase. El sitio los lee solo.
El precio escrito en los archivos `.html` es únicamente un respaldo que se ve mientras carga.

Para que un precio de cualquier página siga al CRM, el número se envuelve con la **clave** del producto
(la misma que muestra el CRM, por ejemplo `TINAS|vilcun` o `AA|1800x1200|clear|3mm`):

| Marca en el HTML | Qué hace |
|---|---|
| `<span data-crm-precio="TINAS|vilcun">$479.990</span>` | Muestra el precio actual |
| `<s data-crm-antes="TINAS|vilcun" hidden></s>` | Muestra el precio anterior tachado (se oculta si no hay) |
| `<span data-crm-descuento="TINAS|vilcun" hidden></span>` | Muestra el descuento, ej. -28% |
| `<p data-crm-agotado="TINAS|vilcun" hidden>Sin stock</p>` | Aparece solo cuando la cantidad es 0 |
| `<button data-crm-bloquear="TINAS|vilcun">` | El botón se desactiva cuando la cantidad es 0 |
| `<data data-crm-desde="TINAS">$479.990</data>` | El precio más bajo con stock de esa categoría |

**Producto nuevo:** créalo en el CRM con *＋ Nuevo producto* (te muestra su clave) y usa esa clave
en las marcas de su página. No hay que tocar nada más.
