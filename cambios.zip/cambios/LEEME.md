# Cambios: el precio se actualiza al cambiar la cantidad de planchas

Pantalla: "Paso 2 de 2 — Tu pedido". Al tocar + / − la cantidad cambiaba,
pero el precio de "Plancha seleccionada" se quedaba en el de 1 plancha.

## El cambio (una línea, en window.pccQtyChange)

```diff
     disp.textContent=next;
     if(window.changeQty)window.changeQty(d);
+    renderCorteResumen(); // actualiza el precio según la cantidad
   };
```

renderCorteResumen() ya multiplica precio × cantidad y agrega "× N u." a la descripción.
Ejemplo 180×120 cm · 2mm: 1 u. = $ 28.322, 2 u. = $ 56.644.

## Cómo subirlo a main

Copia esta carpeta a la raíz de tu repo y ejecuta:

```bash
git checkout main && git pull
node aplicar-cambios.js
git add -A
git commit -m "Fix: actualizar precio al cambiar cantidad de planchas"
git push origin main
```

`aplicar-cambios.js` busca solo el archivo (sirve aunque no esté en public/legacy/m/).
Alternativa: `git apply fix-precio-cantidad.patch` si el archivo está en public/legacy/m/19b75fab98.js.
Después puedes borrar aplicar-cambios.js, el .patch y este LEEME antes del commit si no los quieres en el repo.
