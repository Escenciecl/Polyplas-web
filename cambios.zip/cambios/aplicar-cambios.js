// Uso: desde la raíz del repo ->  node aplicar-cambios.js
// Busca el archivo que define window.pccQtyChange y agrega renderCorteResumen()
const fs = require('fs'), path = require('path');
const OLD = "    if(window.changeQty)window.changeQty(d);\n  };";
const NEW = "    if(window.changeQty)window.changeQty(d);\n    renderCorteResumen(); // actualiza el precio según la cantidad\n  };";
const skip = new Set(['node_modules', '.git', '.next', 'out', 'dist', 'build']);
let hechos = 0;
(function walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) { if (!skip.has(e.name)) walk(p); continue; }
    if (!/\.(js|ts|jsx|tsx|html)$/.test(e.name)) continue;
    let src = fs.readFileSync(p, 'utf8');
    if (!src.includes('window.pccQtyChange')) continue;
    if (src.includes('renderCorteResumen(); // actualiza el precio')) { console.log('Ya aplicado:', p); hechos++; continue; }
    const eol = src.includes('\r\n') ? '\r\n' : '\n';
    const o = OLD.replace(/\n/g, eol), n = NEW.replace(/\n/g, eol);
    if (!src.includes(o)) { console.log('No coincide el código en:', p); continue; }
    fs.writeFileSync(p, src.replace(o, n));
    console.log('Cambio aplicado en:', p); hechos++;
  }
})(process.cwd());
if (!hechos) { console.log('No se encontró window.pccQtyChange en este repo.'); process.exit(1); }
