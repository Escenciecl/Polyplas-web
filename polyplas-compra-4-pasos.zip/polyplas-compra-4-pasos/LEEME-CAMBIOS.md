# Compra en 4 pasos

1. Medida y espesor · 2. Cortes · 3. Datos y envío · 4. Resumen y pago

## Archivos (reemplazan a los actuales, mismas rutas)

- content/modulos/00-flotantes/04-carrito-y-pago.html  → "Finalizar pedido" (pasos 3 y 4, común a todo el sitio)
- content/modulos/04-planchas-acrilico/06-compra-planchas-de-acrilico-online-facil.html
- content/modulos/05-planchas-pet/05-compra-planchas-de-pet-online-facil-rapi.html
- content/modulos/06-planchas-petg/06-compra-planchas-de-petg-online-facil-rap.html
- content/modulos/07-policarbonato/05-compra-policarbonato-compacto-online-fac.html
- public/legacy/pp-track.js  (solo se actualizó el comentario con la lista de eventos)

## Cómo subirlo

Opción A (web de GitHub): en la raíz del repositorio → Add file → Upload files → arrastra las
carpetas `content` y `public` de este zip (GitHub respeta las rutas) → "Create a new branch" →
Propose changes → revisa la vista previa de Cloudflare → Merge a main.

Opción B (terminal): `git checkout -b compra-4-pasos && git am compra-4-pasos.patch && git push -u origin compra-4-pasos`

## Qué cambia

- Configurador de planchas: el paso 2 "Cortes" termina en "Continuar" (va directo a tus datos) y
  "Agregar al carro y seguir comprando". El resumen del configurador ya no se muestra: se arma igual
  que antes (mismo código) y el pedido se agrega al carro con el mismo botón interno "Ir al pago".
- "Finalizar pedido": datos de factura y entrega en una sola pantalla (las opciones de entrega se
  calculan con la región/comuna de los datos, con las mismas reglas), luego "Resumen y pago" con
  Webpay o transferencia. Mismo diseño que el configurador. Envío, embalaje, términos, CRM, Webpay y
  transferencia no cambian.

## Eventos (GA4 / dataLayer)

begin_checkout (abre paso 3) · pago_datos_error / pago_datos_ok (Continuar al pago) ·
add_shipping_info con shipping_tier (Continuar al pago, ya no al tocar cada opción) · pago_resumen
(paso 4) · add_payment_info · purchase. Nuevos: conf_ir_pago y conf_seguir_comprando (paso 2).
Revisa en GTM si algún disparador usaba clics en los botones viejos ("Continuar", "Elige una
entrega", "← Volver a…"): los IDs ppGC-btn-wp, ppGC-wa-link y los de los campos se mantienen.
